
alter table public.photos add column exif_data jsonb;
