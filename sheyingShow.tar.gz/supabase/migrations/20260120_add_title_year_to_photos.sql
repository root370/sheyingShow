
alter table public.photos add column title text;
alter table public.photos add column year text;
