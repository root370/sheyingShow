-- Delete all exhibitions with the title 'UNTITLED EXHIBITION'
DELETE FROM public.exhibitions 
WHERE title = 'UNTITLED EXHIBITION';
